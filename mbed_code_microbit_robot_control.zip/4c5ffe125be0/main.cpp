/*
MicroBit_Robot_Control

A program that uses the MicroBit to control the movement of a small robot,
using a L298 H-Bridge module.
Copyright (c) 2018 Tayeb Habib

NOTE: The Mbed line compiler uses mbed_app.json, instead of 
config.json. We have placed mbed_app.json 
You will get several watnings - ignore them as they are just warnings

Permission is hereby granted, free of charge, to any person obtaining a copy 
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights 
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell    
copies of the Software, and to permit persons to whom the Software is        
furnished to do so, subject to the following conditions:                     
                                                                             
The above copyright notice and this permission notice shall be included in   
all copies or substantial portions of the Software.                          
                                                                             
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR   
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,     
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE  
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER       
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN    
THE SOFTWARE. 

*/



#include "MicroBit.h"
#include "MicroBitUARTService.h"

// motor pins
#define ENA        P2
#define ENB        P1

// motor controls forward, backward, etc
#define IN1        P5
#define IN2        P12
#define IN3        P0
#define IN4        P8

MicroBit uBit;
MicroBitUARTService *uart;
int connected = 0;

// motor spped assuming suppky of 5V 
int speed = 500;


void motorson() //moves robot forward 
{
    uBit.io.ENA.setAnalogValue(speed);
    uBit.io.ENB.setAnalogValue(speed);
}

void motorsoff() //moves robot forward 
{
    uBit.io.ENA.setDigitalValue(0);
    uBit.io.ENB.setDigitalValue(0);
}

void forward() //moves robot forward 
{
    uBit.io.IN1.setDigitalValue(1);
    uBit.io.IN2.setDigitalValue(0);
    uBit.io.IN3.setDigitalValue(1);
    uBit.io.IN4.setDigitalValue(0);
}

void backward() //moves robot vackward
{
    uBit.io.IN1.setDigitalValue(0);
    uBit.io.IN2.setDigitalValue(1);
    uBit.io.IN3.setDigitalValue(0);
    uBit.io.IN4.setDigitalValue(1);
}

void left() //moves robot left
{
    uBit.io.IN1.setDigitalValue(0);
    uBit.io.IN2.setDigitalValue(0);
    uBit.io.IN3.setDigitalValue(1);
    uBit.io.IN4.setDigitalValue(0);
}

void right() //moves robot right
{
    uBit.io.IN1.setDigitalValue(1);
    uBit.io.IN2.setDigitalValue(0);
    uBit.io.IN3.setDigitalValue(0);
    uBit.io.IN4.setDigitalValue(0);
}

void stop() //stops the motors
{
    uBit.io.IN1.setDigitalValue(0);
    uBit.io.IN2.setDigitalValue(0);
    uBit.io.IN3.setDigitalValue(0);
    uBit.io.IN4.setDigitalValue(0);
}


void onConnected(MicroBitEvent)
{

    uBit.display.print("C");

    connected = 1;

    while(1) {
        connected = 1;
        ManagedString msg = uart->read(1);
        if (msg == "S") {
            motorsoff();
            stop();
            uBit.display.print(msg);
        }
        if (msg == "F") {
            motorson();
            forward();
            uBit.display.print(msg);
        }
        if (msg == "B") {
            motorson();
            backward();
            uBit.display.print(msg);
        }
        if (msg == "R") {
            motorson();
            right();
            uBit.display.print(msg);
        }  
        if (msg == "L") {
            motorson();
            left();
            uBit.display.print(msg);
        }     
    }
}

void onDisconnected(MicroBitEvent)
{
    connected = 0;
    motorsoff();
    uBit.display.print("D");
}




#ifndef MICROBIT_SD_GATT_TABLE_SIZE
#define MICROBIT_SD_GATT_TABLE_SIZE     0x600
#endif


int main()
{
    // Initialise the micro:bit runtime.
    uBit.init();
    
    uBit.display.scroll("I LOVE FAIZ");
    
    uBit.messageBus.listen(MICROBIT_ID_BLE, MICROBIT_BLE_EVT_CONNECTED, onConnected);
    uBit.messageBus.listen(MICROBIT_ID_BLE, MICROBIT_BLE_EVT_DISCONNECTED, onDisconnected);
    
    uart = new MicroBitUARTService(*uBit.ble, 32, 32);
    
    
    release_fiber();
}

